document.getElementById('registration-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const email = document.getElementById('email').value;
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;

    // Check if password and confirm password match
    if (password !== confirmPassword) {
        displayMessage("Passwords do not match");
        return;
    }

    // Validate email format
    if (!validateEmail(email)) {
        displayMessage("Invalid email address");
        return;
    }

    // Validate password strength
    if (!validatePassword(password)) {
        displayMessage("Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, and one digit.");
        return;
    }

    // Send registration data to backend
    const registrationData = {
        email: email,
        username: username,
        password: password
    };

    // Example: Send registration data to server using fetch API
    fetch('http://example.com/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(registrationData)
    })
    .then(response => {
        if (response.ok) {
            // Registration successful, display success message
            displayMessage("Registration successful! You will be redirected to your dashboard shortly.");
            // Redirect to dashboard after a short delay
            setTimeout(() => {
                window.location.href = "dashboard.html";
            }, 3000);
        } else {
            // Registration failed, display error message
            displayMessage("Registration failed. Please try again.");
        }
    })
    .catch(error => {
        console.error('Error:', error);
        // Display error message
        displayMessage("An error occurred. Please try again later.");
    });
});