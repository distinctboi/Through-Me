const messages = JSON.parse(localStorage.getItem('messages')) || {};

// Utility functions
function saveToLocalStorage(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
}

function showPage(pageId) {
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    document.getElementById(pageId).classList.add('active');

    if (pageId === 'friendlist' && currentUser) {
        loadFriends();
    } else if (pageId === 'profile' && currentUser) {
        document.getElementById('profileUsername').innerText = currentUser.username;
    }
}

function login() {
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
        currentUser = user;
        saveToLocalStorage('currentUser', currentUser);
        showPage('friendlist');
        alert('Login successful!');
    } else {
        alert('Invalid username or password.');
    }
}

function signup() {
    const username = document.getElementById('signupUsername').value;
    const password = document.getElementById('signupPassword').value;

    if (users.find(u => u.username === username)) {
        alert('Username already exists.');
    } else {
        const newUser = { username, password };
        users.push(newUser);
        saveToLocalStorage('users', users);
        alert('Signup successful! You can now log in.');
        showPage('login');
    }
}

function logout() {
    currentUser = null;
    localStorage.removeItem('currentUser');
    showPage('home');
}

function editProfile() {
    const newPassword = document.getElementById('editPassword').value;
    currentUser.password = newPassword;
    saveToLocalStorage('currentUser', currentUser);
    saveToLocalStorage('users', users.map(u => u.username === currentUser.username ? currentUser : u));
    alert('Profile updated successfully!');
}

function loadFriends() {
    const friendsList = document.getElementById('friends');
    friendsList.innerHTML = '';
    users.forEach(user => {
        if (user.username !== currentUser.username) {
            const friendItem = document.createElement('li');
            friendItem.innerText = user.username;
            friendItem.onclick = () => openChat(user.username);
            friendsList.appendChild(friendItem);
        }
    });
}

function searchFriends() {
    const query = document.getElementById('searchFriends').value.toLowerCase();
    const friendsList = document.getElementById('friends');
    friendsList.innerHTML = '';
    users.filter(user => user.username.toLowerCase().includes(query) && user.username !== currentUser.username)
        .forEach(user => {
            const friendItem = document.createElement('li');
            friendItem.innerText = user.username;
            friendItem.onclick = () => openChat(user.username);
            friendsList.appendChild(friendItem);
        });
}

function openChat(friendUsername) {
    document.getElementById('chatFriendName').innerText = friendUsername;
    showPage('chat');
    loadMessages(friendUsername);
}

function loadMessages(friendUsername) {
    const messagesContainer = document.getElementById('messages');
    messagesContainer.innerHTML = '';
    const chatKey = [currentUser.username, friendUsername].sort().join('-');
    const chatMessages = messages[chatKey] || [];

    chatMessages.forEach(msg => {
        const messageDiv = document.createElement('div');
        messageDiv.innerText = `${msg.sender}: ${msg.text} (${new Date(msg.timestamp).toLocaleTimeString()})`;
        messagesContainer.appendChild(messageDiv);
    });
}

function sendMessage() {
    const messageText = document.getElementById('messageInput').value;
    const friendUsername = document.getElementById('chatFriendName').innerText;
    const chatKey = [currentUser.username, friendUsername].sort().join('-');
    const newMessage = {
        sender: currentUser.username,
        text: messageText,
        timestamp: new Date().toISOString()
    };

    if (!messages[chatKey]) {
        messages[chatKey] = [];
    }
    messages[chatKey].push(newMessage);
    saveToLocalStorage('messages', messages);
    loadMessages(friendUsername);
    document.getElementById('messageInput').value = '';
}

// Initial setup
document.addEventListener('DOMContentLoaded', () => {
    if (currentUser) {
        showPage('friendlist');
    } else {
        showPage('home');
    }
});