// Simulated friend list data
const friends = ['Friend 1', 'Friend 2', 'Friend 3'];

// Display friends dynamically
const friendsContainer = document.getElementById('friends-container');
friends.forEach(friend => {
    const li = document.createElement('li');
    li.textContent = friend;
    friendsContainer.appendChild(li);
});