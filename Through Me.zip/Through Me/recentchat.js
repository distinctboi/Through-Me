// Fetch recent chat history
// Display recent chat list dynamically
const recentChatsList = document.getElementById('recent-chats-list');

// Add event listener to each recent chat item to open chat interface for that friend
recentChatsList.addEventListener('click', function(event) {
    if (event.target.classList.contains('recent-chat-item')) {
        const friendName = event.target.textContent;
        // Open chat interface for the selected friend
        // You can load the chat interface dynamically or redirect to a specific URL
    }
});