// Fetch and display friend list
fetch('http://example.com/friends')
.then(response => response.json())
.then(data => {
    const friendListContainer = document.getElementById('friend-list');
    data.forEach(friend => {
        const li = document.createElement('li');
        li.textContent = friend.username;
        friendListContainer.appendChild(li);
    });
})
.catch(error => {
    console.error('Error:', error);
    // Display error message
    displayMessage("An error occurred while fetching friend list. Please try again later.");
});

// Fetch and display recent chats
fetch('http://example.com/recent-chats')
.then(response => response.json())
.then(data => {
    const recentChatsList = document.getElementById('recent-chats-list');
    data.forEach(chat => {
        const li = document.createElement('li');
        li.textContent = chat.message;
        recentChatsList.appendChild(li);
    });
})
.catch(error => {
    console.error('Error:', error);
    // Display error message
    displayMessage("An error occurred while fetching recent chats. Please try again later.");
});