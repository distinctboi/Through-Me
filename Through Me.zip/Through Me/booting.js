// booting.js

// Simulate loading process
window.addEventListener('load', function() {
    // Simulate loading time
    setTimeout(function() {
        // Hide booting screen and show main content
        document.querySelector('.booting-container').style.display = 'none';
        // You can redirect to login page or dashboard here
        // For example:
        window.location.href = 'login.html'; // Redirect to login page
    }, 3000); // 3 seconds loading time
});